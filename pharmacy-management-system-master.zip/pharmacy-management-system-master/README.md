# pharmacy-management-system
A pharmacy management system with full functionality
Dmoe url : http://trustonepharmacy.somrat.info/
